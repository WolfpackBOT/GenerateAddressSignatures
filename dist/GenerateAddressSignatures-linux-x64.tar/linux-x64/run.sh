#!/usr/bin/env bash
sudo ./GenerateAddressSignatures "wolfcoin-cli" "WalletSignatures.txt"